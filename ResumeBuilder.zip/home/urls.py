from django.contrib import admin
from django.urls import path
from home import views

urlpatterns = [
    path('',views.index, name='home'),
    path('sign-up',views.sign_up, name='sign-up'),
    path('sign-in',views.sign_in, name='sign-in'),
    path('signup_con',views.signup_con, name='signup_con'),
    path('signin_con',views.signin_con, name='signin_con'),
    path('verification', views.verification, name="verification"),
    path('resend_ver_email', views.resend_ver_email, name="resend_verification_email"),
    path('forgot-password.html',views.fp, name='Forgot_Password'),
    path('forgot-password',views.forgot_password, name="Forgot_Password_Controller")
]